import App from "./App/App";

export {App };