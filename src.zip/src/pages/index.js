import Header from "./Header/Header";
import Main from "./Main/Main";
import Page from "./Page/Page";

export { Header, Main, Page };